<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Услуги</title>
    <link rel="stylesheet" type="text/css" href="css/uslugi/style.css">
    <link rel="stylesheet" type="text/css" href="./style.css">
    <link rel="shortcut icon" href="favicon.ico">
</head>

<body>
    <header>
        <?php
            require './header.php';
        ?>
    </header>

    <div class="container">
        <div class="uslugi">
            <div class="uslugi-title">Услуги</div>
            <div class="uslugi-katalog">
                <div class="u-kat-title">Доставка растений на участок</div>
                <div class="u-kat-text">Доставка приобретенной покупки из нашего
                    садового центра осуществляется различными видами транспорта и
                    зависит от количества и размеров заказанного посадочного материала.
                    Мы готовы организовать...
                </div>
                <div class="u-kat-add">
                    <img>
                </div>
            </div>

            <div class="uslugi-katalog">
                <div class="u-kat-title">Доставка растений на участок</div>
                <div class="u-kat-text">Доставка приобретенной покупки из нашего
                    садового центра осуществляется различными видами транспорта и
                    зависит от количества и размеров заказанного посадочного материала.
                    Мы готовы организовать...
                </div>
                <div class="u-kat-add">
                    <img>
                </div>
            </div>

            <div class="uslugi-katalog">
                <div class="u-kat-title">Доставка растений на участок</div>
                <div class="u-kat-text">Доставка приобретенной покупки из нашего
                    садового центра осуществляется различными видами транспорта и
                    зависит от количества и размеров заказанного посадочного материала.
                    Мы готовы организовать...
                </div>
                <div class="u-kat-add">
                    <img>
                </div>
            </div>
        </div>
    </div>


    <footer>
        <?php
            require './footer.php';
        ?>
    </footer>
</body>

</html>